# RESTful Microservice


## Objectif

Créer un micro service qui permet de gérer des comptes bancaires.

## Architecture

![Untitled-2](https://user-images.githubusercontent.com/49799187/212204345-c2b24e64-9e2f-40d5-9430-b9f9f0278548.jpg)


## Exécution

### GET/api/bankAccounts
![image](https://user-images.githubusercontent.com/49799187/212187394-9ee8dda9-b593-4a27-a377-fa9cfca16c48.png)

### PUT/api/bankAccounts/4f8944ca-af72-4f9d-b55a-fa604753eb86
![image](https://user-images.githubusercontent.com/49799187/212187861-57554187-5bfd-41d2-93d9-617bec4e5749.png)

### DELETE/api/bankAccounts/4f8944ca-af72-4f9d-b55a-fa604753eb86
![image](https://user-images.githubusercontent.com/49799187/212188113-ea7d54d3-5396-48f8-b842-aafe6ebdaa3b.png)

### GET/api/bankAccounts/a370f3ce-bb16-42fe-ac12-9fcef2a87ad5
![image](https://user-images.githubusercontent.com/49799187/212189405-f832ef21-1a41-4453-93cb-4a9462363a65.png)

### POST/api/bankAccounts
![image](https://user-images.githubusercontent.com/49799187/212191557-d5008270-4fb1-470a-972e-c2357276dd23.png)
